# from flask_restful import Resource

# class ApiHandler(Resource):
#     def get(self):
#         return {
#             'resultstatus': 'SUCCESS',
#             'message': "Hello Api Handler.py"
#         }