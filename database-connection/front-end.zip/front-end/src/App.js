import React, { useState, useEffect } from 'react';
import SpeechRecognition, { useSpeechRecognition } from 'react-speech-recognition';
import axios from 'axios';
import { FaMicrophoneAlt } from "react-icons/fa"; //icons
import { AiOutlineStop } from "react-icons/ai";
import { GrPowerReset } from "react-icons/gr";
import './App.css';


function App() {
  const [questions, setQuestions] = useState([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false); // this is to track if answer should be displayed for each question..................
  
  //speech recognition
  const {
    transcript,
    listening,
    resetTranscript,
    browserSupportsSpeechRecognition
  } = useSpeechRecognition();

  const [isListening, setIsListening] = useState(false);

   useEffect(() => {
    axios.get('http://127.0.0.1:5000/flask')
      .then(response => {
        setQuestions(response.data.data);
      })
      .catch(error => {
        console.error('Error fetching questions:', error);
      });
  }, []);

  const handleNextQuestion = () => {
    setCurrentQuestion(currentQuestion + 1);
    resetTranscript(); // Reseting transcript when moving to the next question
    setShowAnswer(false); // Hiding the answer for the new question............................
  };

  //speech recognition
  const startListening = () => {
    SpeechRecognition.startListening({ continuous: true });
    setIsListening(true);
  };

  const stopListening = () => {
    SpeechRecognition.stopListening();
    setIsListening(false);
    };
    
if (!browserSupportsSpeechRecognition) {
    return <span>Your Browser does not support</span>;
  }

  return (
    <div className="App">
      <div className='container'>
      {questions.length > 0 && (
        <div>
          <h2>Question {currentQuestion + 1}</h2>
          <p>{questions[currentQuestion].Question}</p>

          {!showAnswer && (                                                      //answer.........
              <button onClick={() => setShowAnswer(true)}>Show Answer</button>
            )}
            {showAnswer && (
              <p>Answer: {questions[currentQuestion].Answers}</p>
            )}                                                                   
          {currentQuestion < questions.length - 1 && (
            <button onClick={handleNextQuestion}>Next</button>
          )}
        </div>
      )}
    </div>

    {/* SpeechRecognition */}
    <div className='container'>
        <p>Microphone: {listening ? 'on' : 'off'}</p>
        <div className='button-names'>
       <button onClick={startListening} disabled={isListening}><FaMicrophoneAlt size={20} />start</button>
        <button onClick={stopListening} disabled={!isListening}><AiOutlineStop size={20}/>Stop</button>
        <button onClick={resetTranscript}><GrPowerReset size={20} />Reset</button>
        </div>
        <p>{transcript}</p>
      </div>
    </div>
  );
}

export default App;

